// menu.h
#ifndef MENU_H
#define MENU_H

unsigned char showMainMenu();

#endif
