#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>

#define MAX_SIZE 20
#include "game2.h"
char maze[MAX_SIZE][MAX_SIZE];
int rows, cols;
int playerX, playerY;
int goalX, goalY;
int maxTime;

typedef struct {
    int x, y;
} Position;

void generateMaze(int level) {
    rows = 10 + (level - 1) * 5;
    cols = 10 + (level - 1) * 5;

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            maze[i][j] = '#';
        }
    }

    for (int i = 1; i < rows - 1; i += 2) {
        for (int j = 1; j < cols - 1; j += 2) {
            maze[i][j] = ' ';
            if (i + 1 < rows - 1) maze[i + 1][j] = ' ';
            if (j + 1 < cols - 1) maze[i][j + 1] = ' ';
        }
    }

    playerX = 1; playerY = 1;
    goalX = rows - 2; goalY = cols - 2;
    maze[playerY][playerX] = 'P';
    maze[goalY][goalX] = 'G';
}

void drawMaze() {
    system("cls");
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%c ", maze[i][j]);
        }
        printf("\n");
    }
    printf("Use W A S D to move. Press O to quit.\n");
}

void movePlayer(char direction) {
    int newX = playerX, newY = playerY;
    switch (direction) {
        case 'w': newY--; break;
        case 's': newY++; break;
        case 'a': newX--; break;
        case 'd': newX++; break;
        case 'o': exit(0);
        default: return;
    }
    if (newX > 0 && newX < cols - 1 && newY > 0 && newY < rows - 1 && maze[newY][newX] != '#') {
        maze[playerY][playerX] = ' ';
        playerX = newX;
        playerY = newY;
        maze[playerY][playerX] = 'P';
    }
}

void maze1() {
    int difficulty;
    printf("Welcome to the Maze Game!\n");
    printf("Select difficulty (1-Easy, 2-Medium, 3-Hard): ");
    scanf("%d", &difficulty);

    switch (difficulty) {
        case 1: maxTime = 120; break;
        case 2: maxTime = 90; break;
        case 3: maxTime = 60; break;
        default: maxTime = 120;
    }

    for (int level = 1; level <= 3; level++) {
        generateMaze(level);
        clock_t startTime = clock();

        while (playerX != goalX || playerY != goalY) {
            drawMaze();
            char input = _getch();
            movePlayer(input);

            if (((clock() - startTime) / CLOCKS_PER_SEC) > maxTime) {
                printf("Time's up! You failed the level.\n");
                return 0;
            }
        }
        printf("Congratulations! You completed level %d!\n", level);
    }

    printf("You won! You finished all levels!\n");
}
