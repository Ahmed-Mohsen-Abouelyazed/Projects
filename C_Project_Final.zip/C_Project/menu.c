// menu.c
#include <stdio.h>
#include "menu.h"

unsigned char showMainMenu() {
    int choice;
    unsigned char game_Selc;
        printf("=== Game Hub ===\n");
        printf("1. Game 1\n");
        printf("2. Game 2\n");
		printf("3. Game 3\n");
		printf("4. Game 4\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Launching Game 1...\n");
                game_Selc=1;
                break;
            case 2:
                printf("Launching Game 2...\n");
                game_Selc=2;
                break;
            case 3:
                printf("Launching Game 3...\n");
                game_Selc=3;
                break;
			case 4:
                printf("Launching Game 4...\n");
                game_Selc=4;
                break;
			case 5:
                printf("Exiting Game Hub. Goodbye!\n");
                game_Selc=6;
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
        return game_Selc;
    }
