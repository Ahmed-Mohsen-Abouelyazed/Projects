#ifndef LOGIN_H
#define LOGIN_H

#define MAX_USERNAME_LENGTH 20
#define MAX_PASSWORD_LENGTH 20

void login();

#endif
