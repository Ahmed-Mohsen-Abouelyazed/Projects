void maze1();
