#include <stdio.h>
#include "login.h"

void login() {
    char username[MAX_USERNAME_LENGTH];
    char password[MAX_PASSWORD_LENGTH];
    int i, length, pass_length, valid_password;

    while (1) {
     
        printf("Enter your username: ");
        fflush(stdin);  
        gets(username); 

        length = 0;
        for (i = 0; username[i] != '\0'; i++) {
            length++;
        }

        if (length == 0) {
            printf("Invalid username. Please try again.\n");
            continue;
        }

       
        while (1) {
            printf("Enter your password (at least 5 digits): ");
            fflush(stdin);  
            gets(password); 

           
            pass_length = 0;
            valid_password = 1;
            for (i = 0; password[i] != '\0'; i++) {
                pass_length++;

                
                if (password[i] < '0' || password[i] > '9') {
                    valid_password = 0;
                }
            }

            if (pass_length >= 5 && valid_password) {
                break;
            } else {
                printf("Invalid password! Password must be at least 5 digits and contain only numbers. Try again.\n");
            }
        }

      
        printf("Login successful! Welcome, %s.\n\n", username);
        break;
    }
}
