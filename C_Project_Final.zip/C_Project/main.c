#include <stdio.h>
#include <stdlib.h>
#include "menu.h"
#include "login.h"
unsigned char game_selc=0;
int main()
{
    while(1){
    login();
    game_selc=showMainMenu();

    switch (game_selc) {
            case 1:
                game1();
                break;
            case 2:
                maze1();
                break;
            case 3:
                    snake();
                break;
			case 4:
                xo();

                break;
			case 5:

                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
    return 0;
}
